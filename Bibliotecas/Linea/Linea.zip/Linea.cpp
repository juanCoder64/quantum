#include "Arduino.h"
#include "Linea.h"
Linea::Linea(int centro,int medio,int exterior,int ledpin){
pinMode(ledpin,OUTPUT);
digitalWrite(ledpin,HIGH);	
gcentro=centro;
gmedio=medio;
gexterior=exterior;
}
void Linea::calibrarV(){
	digitalWrite(ledpin,HIGH);
  a = analogRead(gcentro);
  b = analogRead(gmedio);
  c = analogRead(gexterior);
  }
 int Linea::calibrarB(){
 digitalWrite(ledpin,HIGH);
  Ca = analogRead(gcentro);
  Cb = analogRead(gmedio);
  Cc = analogRead(gexterior);
  Cc += c;
  Cb += b;
  Ca += a;
  Cc /= 2;
  Cb /= 2;
  Ca /= 2;
 }

int Linea::lectura(){
	digitalWrite(ledpin,HIGH);
  a = analogRead(gcentro);
  b = analogRead(gmedio);
  c = analogRead(gexterior);
  if (a >= Ca) {
  	return 3;
  }
  else if (b >= Cb) {
  	return 2;
  }
  else if (c >= Cc) {
  	return 1;
  }
  else{
  //(c <= Cc && b >= Cb && a >= Ca){
  	return 0;
  }
}
