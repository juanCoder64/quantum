#include "Arduino.h"
#ifndef Enviar_h
#define Enviar_h
class Movimiento{
public:
Movimiento(int);
void muevete(int ANGLE,int MAXSpeed,int brujula);
void rota(int brujula);
void recio();
private:
int a;
int b;
int c;
int d;
int speed;
float P,I,D,PID;
int _angle;
int _MAXSpeed;
};
#endif
