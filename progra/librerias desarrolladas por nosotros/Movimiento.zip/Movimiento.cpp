#include "Arduino.h"
#include "Movimiento.h"
Movimiento::Movimiento(int){
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(7, OUTPUT);
  pinMode(8, OUTPUT);
  pinMode(9, OUTPUT);
}
void Movimiento::muevete(int ANGLE,int MAXSpeed) {
    ANGLE=_angle;
  MAXSpeed=_MAXSpeed;
    a = sin(((_angle - 45) * PI) / 180)*_MAXSpeed;
  b = sin(((_angle - 135) * PI) / 180)*_MAXSpeed;
  d = sin(((_angle - 315) * PI) / 180)*_MAXSpeed;
  c = sin(((_angle - 225) * PI) / 180)*_MAXSpeed;
if(a>0){
  analogWrite(2, LOW);
  analogWrite(3, -a);
}
else{
  analogWrite(2, a);
  analogWrite(3, LOW);

}
//----------------
 if(b>0){
  analogWrite(4, LOW);
  analogWrite(5, -b);
}
else{
  analogWrite(4, b);
  analogWrite(5, LOW);

}
//---------------
if(c>0){
  analogWrite(6, LOW);
  analogWrite(7, -c);
}
else{
  analogWrite(6, c);
  analogWrite(7, LOW);

}
//-------------------------
if(d>0){
  analogWrite(8, LOW);
  analogWrite(9, -d);
}
else{
  analogWrite(8, d);
  analogWrite(9, LOW);

}
}
