#include "Arduino.h"
#include "Movimiento.h"
Movimiento::Movimiento(int){

  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(7, OUTPUT);
  pinMode(8, OUTPUT);
  pinMode(9, OUTPUT);
}
void Movimiento::muevete(int ANGLE,int MAXSpeed) {
    a = sin(((ANGLE + 45) * PI) / 180)*MAXSpeed;
    b = sin(((ANGLE + 135) * PI) / 180)*MAXSpeed;
    c = sin(((ANGLE + 225) * PI) / 180)*MAXSpeed;
    d = sin(((ANGLE + 315) * PI) / 180)*MAXSpeed;

        if(a>255){
        a=255;
    }
        if(b>255){
        b=255;
    }
        if(c>255){
        c=255;
    }
        if(d>255){
        d=255;
    }
if(a>0){
  analogWrite(2, LOW);
  analogWrite(3, -a);
  a=-a;
}
else{
  analogWrite(2, a);
  analogWrite(3, LOW);

}
//----------------
 if(b>0){
  analogWrite(4, LOW);
  analogWrite(5, -b);
  b=-b;
}
else{
  analogWrite(4, b);
  analogWrite(5, LOW);
}
if(c>0){
  analogWrite(6, LOW);
  analogWrite(7, -c);
  c=-c;
}
else{
  analogWrite(6, c);
  analogWrite(7, LOW);

}
if(d>0){
  analogWrite(8, LOW);
  analogWrite(9, -d);
  d=-d;
}
else{
  analogWrite(8, d);
  analogWrite(9, LOW);

}
    Serial.print(a);
    Serial.print("\t");
    Serial.print(b);
    Serial.print("\t");
    Serial.print(c);
    Serial.print("\t");
    Serial.print(d);
    Serial.println("");
}
void Movimiento::rota(int speed, int lado){
    if(lado == 0){
    analogWrite(2, speed);
    analogWrite(3, LOW);
    analogWrite(4, speed);
    analogWrite(5, LOW);
    analogWrite(6, speed);
    analogWrite(7, LOW);
    analogWrite(8, speed);
    analogWrite(9, LOW);
        Serial.println(lado);
    Serial.print(speed);
    }
    if(lado == 1){
    analogWrite(2, LOW);
    analogWrite(3, speed);
    analogWrite(4, LOW);
    analogWrite(5, speed);
    analogWrite(6, LOW);
    analogWrite(7, speed);
    analogWrite(8, LOW);
    analogWrite(9, speed);
        Serial.println(lado);
    Serial.print(speed);
    }
}
