#include "Arduino.h"
#ifndef Enviar_h
#define Enviar_h
class Movimiento{
public:
Movimiento(int);
void muevete(int, int);
private:
int a;
int b;
int c;
int d;
int _angle;
int _MAXSpeed;
};
#endif
