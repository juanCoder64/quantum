#ifndef Enviar_h
#define Enviar_h
#include "Arduino.h"
class Movimiento{
public:
Movimiento(int velocidad);
void derecha();
void atrasizquierda();
void atrasderecha();
void apagado();
void izquierda();

void adelante();
void atras();
private:
int vel;
};
#endif
