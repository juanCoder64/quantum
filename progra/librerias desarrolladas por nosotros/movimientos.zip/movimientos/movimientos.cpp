#include "Arduino.h"
#include "movimientos.h"
Movimiento::Movimiento(int velocidad){
  vel=velocidad;
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);

  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);

  pinMode(6, OUTPUT);
  pinMode(7, OUTPUT);

  pinMode(8, OUTPUT);
  pinMode(9, OUTPUT);
}
void Movimiento::derecha(){

  analogWrite(2, vel);
  analogWrite(3, 0);
  analogWrite(4, vel);
  analogWrite(5, 0);
  analogWrite(6, vel);
  analogWrite(7, 0);
  analogWrite(8, vel);
  analogWrite(9, 0);
     Serial.print("\t");
  Serial.print("derecha");
}
void Movimiento::izquierda() {
  analogWrite(2, 0);
  analogWrite(3, vel);
  analogWrite(4, 0);
  analogWrite(5, vel);
  analogWrite(6, 0);
  analogWrite(7, vel);
  analogWrite(8, 0);
  analogWrite(9, vel);
   Serial.print("\t");
   Serial.print("izquierda");
}
void Movimiento::apagado() {
  analogWrite(2, 0);
  analogWrite(3, 0);
  analogWrite(4, 0);
  analogWrite(5, 0);
  analogWrite(6, 0);
  analogWrite(7, 0);
  analogWrite(8, 0);
  analogWrite(9, 0);
}
void Movimiento:: atrasderecha() {
  analogWrite(2, LOW);
  analogWrite(3, LOW);

  analogWrite(4, LOW);
  analogWrite(5, 150);

  analogWrite(6, 150);
  analogWrite(7, LOW);

  analogWrite(8, LOW);
  analogWrite(9, LOW);
}
void Movimiento::atrasizquierda() {
  analogWrite(2, 150);
  analogWrite(3, LOW);

  analogWrite(4, LOW);
  analogWrite(5, LOW);

  analogWrite(6, LOW);
  analogWrite(7, LOW);

  analogWrite(8, LOW);
  analogWrite(9, 150);
}
void Movimiento::adelante() {
  analogWrite(2, LOW);
  analogWrite(3, 150);

  analogWrite(4, 150);
  analogWrite(5, LOW);

  analogWrite(6, LOW);
  analogWrite(7, 150);

  analogWrite(8, 150);
  analogWrite(9, LOW);
}
void Movimiento::atras() {
  analogWrite(2, 150);
  analogWrite(3, LOW);

  analogWrite(4, LOW);
  analogWrite(5, 150);

  analogWrite(6, 150);
  analogWrite(7, LOW);

  analogWrite(8, LOW);
  analogWrite(9, 150);
}
